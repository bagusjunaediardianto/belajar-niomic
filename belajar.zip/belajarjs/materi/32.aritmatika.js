var a = 10
var b = 20

console.log(a + b) // penjumlahan
console.log(b - a) // pengurangan
console.log(a * b) // perkalian
console.log(b / a) // pembagian
console.log(b % a) // sisa bagi (modulo)




