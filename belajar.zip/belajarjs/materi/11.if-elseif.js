var x =25

if (x>20)
console.log("x lebih besar dari 20")
else if (x>10)
console.log("x lebih besar dari 10")
else if (x<10)
console.log("x lebih kecil dari 10")
else
console.log("x adalah 10")
