var huruf = "abdefghijklmnopqrstuvwxyz"
var tunggal = 'tunggal'

console.log(huruf)
console.log(tunggal)

