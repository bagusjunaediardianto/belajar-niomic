var perulangan = ()=> {
    for(var i = 0; i < 10; i++){
        console.log("jalan : ",i)
         
    }
}

perulangan()