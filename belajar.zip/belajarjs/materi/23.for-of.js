var angka = [0,1,3,5,7,9]

for (let x of angka){
    console.log(x)
    
}