var testingSwitch = ()=> {
    var nilai = "Aku"

    switch(nilai) {
        case "Aku" : 
        console.log("Sangat bagus")
        break
        case 8 : 
        console.log("Baik")
        break
        case 6:
        console.log("Cukup")
        break
        default :
        console.log("Lainnya")
    }
}

testingSwitch()
