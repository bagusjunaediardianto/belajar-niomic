var x = 10
var z = 11

console.log(x>z) //lebih dari
console.log(x<z) //kurang dari
console.log(x>=z) //lebih dari sama dengan
console.log(x<=z) //kurang dari sama dengan
console.log(x == z) //sama dengan
console.log(x === z) //sama dengan tipe data harus sama
console.log(x != z) // tidak sama dengan
console.log(x !== z) // tidak sama dengan tipe data harus sama





