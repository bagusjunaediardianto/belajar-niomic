var tinggi = false
var cm = 165

if (cm<170)
tinggi = true
else
tinggi = false


console.log(tinggi)
