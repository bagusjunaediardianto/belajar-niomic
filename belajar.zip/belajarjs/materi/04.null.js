var kosong = "ada"
kosong = null;

var undefinedVar 
console.log(kosong);

console.log(undefinedVar);

