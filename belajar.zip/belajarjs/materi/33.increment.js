var x = 0

console.log(x)//increment
x++

console.log(x)//increment
x++

console.log(x)//decrement
x--

console.log(x)//decrement
x--

console.log(x)//result



