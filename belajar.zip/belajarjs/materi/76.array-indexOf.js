function panggilindexOf(x,y) {
    console.log(x)

    return x.indexOf(y)    
}

var kota = ["jakarta","medan","bandung","palembang"]

console.log(panggilindexOf(kota,"BANDung".toLowerCase()))
