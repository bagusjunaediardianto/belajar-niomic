var x
var y
var z

x = 20
y = 30
z = 40

console.log(x,y,z)

x = 40
y = 50
z = 60

console.log(x,y,z);


