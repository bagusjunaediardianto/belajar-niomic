function mintadata(x,y,z) {

    console.log(x);
    console.log(y);
    console.log(z);
    
    
}

mintadata("hello","apakabar","sehat")

