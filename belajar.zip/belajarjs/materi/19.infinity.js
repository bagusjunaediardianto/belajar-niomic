// for(var i = 0; i>=0; i++){
//     console.log("i ke - ",i)
    
// }

// untuk menghentikan infinity loop tekan CTRL + C

var i = 1
while (i = i){
    console.log("i ke i - "+i)
    
}