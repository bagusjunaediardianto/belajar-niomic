var panggilforEach = (x)=> {
    x.forEach(function(item, index, array){
        console.log(item,"",index,"",array)
    })
    
}

var data = ["a","b","c"]

panggilforEach(data)