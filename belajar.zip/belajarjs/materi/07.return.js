const ambil =()=> {
    return "terambil"
}

const lempar =()=> {
    var lempar = "ditangkap"
    return lempar
}

const tampung = ambil()

console.log(ambil())
console.log(lempar())
console.log(tampung)


