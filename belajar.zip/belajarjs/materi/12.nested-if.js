var x = 40
var y = 20
var z = 30

if (x > y){
    if(x > z){
        console.log("X adalah yang paling besar")
    }else{
        console.log("X adalah yang terbesar kedua")   
    }
}else{
    if (x < z){
        console.log("X adalah yang terkecil")
    }else{
        console.log("X adalah yang terkecil kedua")
    }
}