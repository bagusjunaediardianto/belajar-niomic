function jalanSatu() {
    var nilai = 2

//     if (nilai === 3){
//         console.log("Benar")
//     }else if (nilai === 2) {
//         console.log("Dua")
//     }else{
//         console.log("salah")
//     }

    if (nilai === 1) console.log("OK")
    else console.log("Bukan")
    
    
}

jalanSatu()