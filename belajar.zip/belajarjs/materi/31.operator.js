function panggilOperator(){
    var a = 4
    var b = 3

    return a**b
    // console.log(a+b)
    
}

console.log(panggilOperator())