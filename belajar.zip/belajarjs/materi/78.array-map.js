var panggilMap = (x)=> {

    x.map(function(item, index,array){
        console.log(item,":",index,"",array)
        
    })
}

var kota = ["jakarta","balikpapan","medan"]

panggilMap(kota)