var panggilObject = ()=> {
    var mobil = {
        type : "Sedan",
        harga : 150000000,
        warna : "putih",
        tahun : [2001,2002,2003,2004]
    }
    mobil.type = 2800
    mobil.merk = "Datsun"
    console.log(mobil)
    console.log(mobil.type)
    console.log(mobil.tahun[2])
}

panggilObject()