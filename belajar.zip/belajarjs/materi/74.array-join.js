function panggilJoin(x,y) {
    console.log(x)
    var result = x.join(y)
    return result
}

var kota = ["jakarta","medan","malang","tangerang"]

console.log(panggilJoin(kota," - "))
