var angka = [5,4,3,2,1]

for (var i = 0; i < angka.length; i++){
    console.log(angka[i])
}