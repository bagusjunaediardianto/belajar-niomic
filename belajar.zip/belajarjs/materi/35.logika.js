var x = 10


console.log(x>5 && x<20) //and
console.log(x>15 || x<10) //or
console.log(!false) //not (negasi)