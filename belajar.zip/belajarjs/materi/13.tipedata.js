function tipedata() {
    var data = '2'
    console.log(typeof(data))
    


    if(data === 2)
        return 'sukses'
    else
        return 'gagal'
    
}

console.log(tipedata())