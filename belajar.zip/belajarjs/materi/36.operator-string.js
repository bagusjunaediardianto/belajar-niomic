var x = "halo"
var y = "teman"
var angka  = 10
var z = x + y + angka

console.log(z)
