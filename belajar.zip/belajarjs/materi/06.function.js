function jalanSatu() {
    console.log("Jalan Satu");
}

const jalanDua = function(){
    console.log("Jalan dua");
    
}

const jalanTiga = ()=> {
    console.log("Jalan Tiga")
    
}
jalanSatu()
jalanDua()
jalanTiga()