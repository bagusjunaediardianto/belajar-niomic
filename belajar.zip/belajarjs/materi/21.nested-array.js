var panggilNestedArray = ()=> {
    var dataNama = [["Ab","Ac","Ad"],
                    ["Bola","Bola2","Bola3"],
                    ["Rem1","Rem2","Rem3"]]

    console.log(dataNama.length)
    console.log(dataNama[0][2])
    console.log(dataNama[1][1])
    
    
    
}

panggilNestedArray()