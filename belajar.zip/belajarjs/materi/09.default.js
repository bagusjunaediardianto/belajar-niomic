function mintadata(x = 10){

    console.log(x);
    
}

mintadata()