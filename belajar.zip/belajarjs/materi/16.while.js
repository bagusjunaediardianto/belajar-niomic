var i = 10

while (i > 0){
    console.log("ini urutan ke - "+i)
    --i
    
}