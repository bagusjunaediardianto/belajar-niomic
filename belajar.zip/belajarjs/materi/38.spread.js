var data = [1,2,3,4,5]
var angka = [6,7,8,9]

var spreaddata = [...data,...angka,10,11]

console.log(data)
console.log(angka)
console.log(spreaddata)


