var angka = 20
var decimal = 30.5
var negatif = -10

console.log(angka)
console.log(decimal)
console.log(negatif)


